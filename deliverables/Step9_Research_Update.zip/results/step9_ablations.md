# Step 9 exploratory component ablations

20 questions, 2 base seeds, 40 matched pairs. Manifest SHA-256: `969462b4f3bc1ec5c568d4872c3169e37665d4d63f2764aafc236ef8f26f5fc1`.

Each system: at most 4 retrievals and 18 LLM calls, including one reserved final-answer call. Identical model, document pools, BM25, context/output limits and final-answer policy. Retrieval-stage temperature is matched; KAIR retains independent agent seeds.

| System | Exact match | Answer F1 | Coverage | Errors | Budget stops | Mean LLM calls | Mean retrievals | Mean seconds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RAIR | 50.0% | 60.6% | 70.0% | 0 | 6 | 11.35 | 2.38 | 14.74 |
| KAIR | 55.0% | 74.7% | 95.0% | 0 | 2 | 8.53 | 1.88 | 19.38 |
| RAIR_NO_VERIFICATION | 55.0% | 73.0% | 95.0% | 0 | 0 | 7.33 | 1.77 | 7.32 |
| RAIR_NO_DECOMPOSITION | 47.5% | 63.6% | 77.5% | 0 | 7 | 9.22 | 2.12 | 11.32 |

All planned runs contribute to answer scores; abstentions and errors are empty predictions.
Equal resource ceilings do not imply equal actual token use or computation. Runtime is serial local timing, with a question-free warm-up and counterbalanced system order; it does not reproduce asynchronous KAIR.

| System | Source-sentence citation F1 | Cumulative retrieval document recall | Mean prompt tokens | Mean output tokens | Agent errors |
| --- | --- | --- | --- | --- | --- |
| RAIR | 59.2% | 95.0% | 8317.5 | 663.8 | 0 |
| KAIR | 63.9% | 90.0% | 11397.1 | 853.1 | 1 |
| RAIR_NO_VERIFICATION | 70.6% | 93.8% | 4634.3 | 303.2 | 0 |
| RAIR_NO_DECOMPOSITION | 54.7% | 86.2% | 6972.8 | 486.4 | 0 |

Citation scores measure overlap with annotated source sentences, not semantic entailment. Retrieval recall uses the union of every paid retrieval, including losing agents. Invalid gold references are flagged and excluded only from source/retrieval metric denominators, never from answer scoring.

Token totals include known counts only. Runs with incomplete token counts: RAIR=0, KAIR=0, RAIR_NO_VERIFICATION=0, RAIR_NO_DECOMPOSITION=0.

## Uncertainty across questions

95% paired question-cluster bootstrap intervals, 10000 resamples, analysis seed 20261031. Seeds stay together when resampling each question. Primary endpoints: the two component-removal EM contrasts below; this RAIR/KAIR table is secondary.

| Endpoint | Estimate | 95% interval |
| --- | --- | --- |
| RAIR exact_match | 50.0% | [27.5%, 70.0%] |
| RAIR answer_f1 | 60.6% | [41.5%, 78.3%] |
| KAIR exact_match | 55.0% | [35.0%, 75.0%] |
| KAIR answer_f1 | 74.7% | [60.0%, 87.8%] |
| KAIR_minus_RAIR exact_match | 5.0% | [-15.0%, 25.0%] |
| KAIR_minus_RAIR answer_f1 | 14.1% | [-2.6%, 31.8%] |

Pointwise approximate intervals across sampled questions; seeds are not independent observations. F1 is secondary; no multiple-comparison adjustment.

## Component removals

Full RAIR minus each removal; 97.5% pointwise question-cluster intervals. Two prespecified EM contrasts; F1 is exploratory. Unchecked admissions are not verified facts.

| Contrast | Endpoint | Estimate | 97.5% interval |
| --- | --- | --- | --- |
| RAIR_minus_RAIR_NO_VERIFICATION | exact_match | -5.0% | [-15.0%, 5.0%] |
| RAIR_minus_RAIR_NO_VERIFICATION | answer_f1 | -12.4% | [-25.0%, 0.3%] |
| RAIR_minus_RAIR_NO_DECOMPOSITION | exact_match | 2.5% | [-15.0%, 17.5%] |
| RAIR_minus_RAIR_NO_DECOMPOSITION | answer_f1 | -3.0% | [-22.0%, 15.0%] |

The no-gate arm admits all structurally valid candidates and resolves a gap after a nonempty admission. The no-decomposition arm replaces generated subquestions with one whole-question gap. Source validation and the final synthesis prompt remain common. Removing a component also removes its calls and can alter stopping; equal ceilings are not equal computation.

| Question | Seed | Full RAIR | KAIR | No gate | No decomposition |
| --- | --- | --- | --- | --- | --- |
| 5abc8d00554299700f9d78fd | 42 | [empty] | 848 | 848 | [empty] |
| 5abc8d00554299700f9d78fd | 43 | 848 | 848 | 848 | 848 |
| 5a81967a55429926c1cdad44 | 42 | Thrushcross Grange | Thrushcross Grange | Thrushcross Grange | Thrushcross Grange |
| 5a81967a55429926c1cdad44 | 43 | [empty] | Thrushcross Grange | Thrushcross Grange | [empty] |
| 5abd8ac25542993062266cc2 | 42 | [empty] | [empty] | 1958 | [empty] |
| 5abd8ac25542993062266cc2 | 43 | 1958 | [empty] | 1974 | [empty] |
| 5a8b3af455429971feec467b | 42 | Unbreakable | Unbreakable | Unbreakable | Unbreakable |
| 5a8b3af455429971feec467b | 43 | Unbreakable | The Whole Nine Yards | [empty] | Unbreakable |
| 5ae791cf55429952e35ea978 | 42 | Siemens | Siemens | Siemens | Siemens |
| 5ae791cf55429952e35ea978 | 43 | Siemens | Siemens | Siemens | Siemens |
| 5ab29426554299545a2cf99f | 42 | Cavaliers | Cleveland Cavaliers | Cavaliers | Cavaliers |
| 5ab29426554299545a2cf99f | 43 | Cavaliers | Cleveland Cavaliers | Cavaliers | Cavaliers |
| 5a738b855542992d56e7e363 | 42 | St. Elizabeths Hospital | St. Elizabeths Hospital | St. Elizabeths Hospital | St. Elizabeths Hospital |
| 5a738b855542992d56e7e363 | 43 | St. Elizabeths Hospital | St. Elizabeths Hospital | St. Elizabeths Hospital | St. Elizabeths Hospital |
| 5ae0132d55429925eb1afc00 | 42 | the George Washington Bridge | the George Washington Bridge | the George Washington Bridge | the George Washington Bridge |
| 5ae0132d55429925eb1afc00 | 43 | the George Washington Bridge | the Hudson Palisades | the George Washington Bridge | the George Washington Bridge |
| 5ae35b035542992e3233c3ae | 42 | Conservative | Conservative | Conservative | Conservative |
| 5ae35b035542992e3233c3ae | 43 | Conservative | Conservative | Conservative | [empty] |
| 5aba74ad55429955dce3ee35 | 42 | [empty] | yes | no | [empty] |
| 5aba74ad55429955dce3ee35 | 43 | [empty] | yes | no | [empty] |
| 5ac07fff554299294b219006 | 42 | tennis | Tennis | tennis | tennis |
| 5ac07fff554299294b219006 | 43 | tennis | Tennis | tennis | [empty] |
| 5ae658855542992ae0d162e3 | 42 | 1976 | 1976 | 1976 | June 1975 |
| 5ae658855542992ae0d162e3 | 43 | [empty] | 1976 | 1976 | [empty] |
| 5a84f7255542991dd0999e33 | 42 | [empty] | Chad | Chad | Chad |
| 5a84f7255542991dd0999e33 | 43 | [empty] | Chad | Chad | Chad |
| 5ac3d90b5542995c82c4ac4b | 42 | [empty] | board games | Board games | German-style board games |
| 5ac3d90b5542995c82c4ac4b | 43 | board games | board games | board games | board games |
| 5a85f8665542994775f606ce | 42 | [empty] | 18 minutes | 18 minutes | 18 minutes |
| 5a85f8665542994775f606ce | 43 | [empty] | 18 minutes | [empty] | 18 minutes |
| 5a7a633a55429941d65f2609 | 42 | Jang Hyun-seung | Jang Hyun-seung | Jang Hyun-seung | Dave Peverett |
| 5a7a633a55429941d65f2609 | 43 | Jang Hyun-seung | Jang Hyun-seung | Jang Hyun-seung | Jang Hyun-seung |
| 5a8b7d7d5542997f31a41d4b | 42 | James Lapine | James Lapine | James Lapine | James Lapine |
| 5a8b7d7d5542997f31a41d4b | 43 | James Lapine | James Lapine | James Lapine | James Lapine |
| 5a8787915542996e4f30882e | 42 | The Man from Snowy River II | The Man from Snowy River II | The Man from Snowy River II | The Man from Snowy River II |
| 5a8787915542996e4f30882e | 43 | The Man from Snowy River II | The Man from Snowy River II | The Man from Snowy River II | The Man from Snowy River II |
| 5ab29624554299545a2cf9b5 | 42 | John Garabedian | John Garabedian | John Garabedian | John Garabedian |
| 5ab29624554299545a2cf9b5 | 43 | [empty] | John Garabedian | John Garabedian | John Garabedian |
| 5a7baae2554299042af8f794 | 42 | Jan Kazimierz | Jan Kazimierz | Jan Kazimierz | John II Casimir Vasa |
| 5a7baae2554299042af8f794 | 43 | Jan Kazimierz | Jan Kazimierz | Jan Kazimierz | Jan Kazimierz |
## Paired predictions

| Question ID | Base seed | RAIR | KAIR | KAIR − RAIR exact match |
| --- | --- | --- | --- | --- |
| 5abc8d00554299700f9d78fd | 42 | [empty] | 848 | +1 |
| 5abc8d00554299700f9d78fd | 43 | 848 | 848 | +0 |
| 5a81967a55429926c1cdad44 | 42 | Thrushcross Grange | Thrushcross Grange | +0 |
| 5a81967a55429926c1cdad44 | 43 | [empty] | Thrushcross Grange | +1 |
| 5abd8ac25542993062266cc2 | 42 | [empty] | [empty] | +0 |
| 5abd8ac25542993062266cc2 | 43 | 1958 | [empty] | +0 |
| 5a8b3af455429971feec467b | 42 | Unbreakable | Unbreakable | +0 |
| 5a8b3af455429971feec467b | 43 | Unbreakable | The Whole Nine Yards | -1 |
| 5ae791cf55429952e35ea978 | 42 | Siemens | Siemens | +0 |
| 5ae791cf55429952e35ea978 | 43 | Siemens | Siemens | +0 |
| 5ab29426554299545a2cf99f | 42 | Cavaliers | Cleveland Cavaliers | -1 |
| 5ab29426554299545a2cf99f | 43 | Cavaliers | Cleveland Cavaliers | -1 |
| 5a738b855542992d56e7e363 | 42 | St. Elizabeths Hospital | St. Elizabeths Hospital | +0 |
| 5a738b855542992d56e7e363 | 43 | St. Elizabeths Hospital | St. Elizabeths Hospital | +0 |
| 5ae0132d55429925eb1afc00 | 42 | the George Washington Bridge | the George Washington Bridge | +0 |
| 5ae0132d55429925eb1afc00 | 43 | the George Washington Bridge | the Hudson Palisades | -1 |
| 5ae35b035542992e3233c3ae | 42 | Conservative | Conservative | +0 |
| 5ae35b035542992e3233c3ae | 43 | Conservative | Conservative | +0 |
| 5aba74ad55429955dce3ee35 | 42 | [empty] | yes | +1 |
| 5aba74ad55429955dce3ee35 | 43 | [empty] | yes | +1 |
| 5ac07fff554299294b219006 | 42 | tennis | Tennis | +0 |
| 5ac07fff554299294b219006 | 43 | tennis | Tennis | +0 |
| 5ae658855542992ae0d162e3 | 42 | 1976 | 1976 | +0 |
| 5ae658855542992ae0d162e3 | 43 | [empty] | 1976 | +0 |
| 5a84f7255542991dd0999e33 | 42 | [empty] | Chad | +0 |
| 5a84f7255542991dd0999e33 | 43 | [empty] | Chad | +0 |
| 5ac3d90b5542995c82c4ac4b | 42 | [empty] | board games | +0 |
| 5ac3d90b5542995c82c4ac4b | 43 | board games | board games | +0 |
| 5a85f8665542994775f606ce | 42 | [empty] | 18 minutes | +1 |
| 5a85f8665542994775f606ce | 43 | [empty] | 18 minutes | +1 |
| 5a7a633a55429941d65f2609 | 42 | Jang Hyun-seung | Jang Hyun-seung | +0 |
| 5a7a633a55429941d65f2609 | 43 | Jang Hyun-seung | Jang Hyun-seung | +0 |
| 5a8b7d7d5542997f31a41d4b | 42 | James Lapine | James Lapine | +0 |
| 5a8b7d7d5542997f31a41d4b | 43 | James Lapine | James Lapine | +0 |
| 5a8787915542996e4f30882e | 42 | The Man from Snowy River II | The Man from Snowy River II | +0 |
| 5a8787915542996e4f30882e | 43 | The Man from Snowy River II | The Man from Snowy River II | +0 |
| 5ab29624554299545a2cf9b5 | 42 | John Garabedian | John Garabedian | +0 |
| 5ab29624554299545a2cf9b5 | 43 | [empty] | John Garabedian | +0 |
| 5a7baae2554299042af8f794 | 42 | Jan Kazimierz | Jan Kazimierz | +0 |
| 5a7baae2554299042af8f794 | 43 | Jan Kazimierz | Jan Kazimierz | +0 |

Exploratory component study. Two prespecified EM contrasts use 97.5% pointwise question-cluster intervals (Bonferroni 95% family coverage, approximately). Other metrics and RAIR versus KAIR are secondary; small-sample bootstrap limits apply. Removing a component also changes call counts and stopping behavior; no equal-compute causal claim.

Keep these evaluated question IDs outside any future untouched evaluation split.
